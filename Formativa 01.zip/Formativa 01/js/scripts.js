
/* ----------------------- Atividade 1 -----------------------*/

function validarDados() {
    let mensagemData = document.getElementById('mensagem-data');
    let mensagemCliente = document.getElementById('mensagem-cli');
    let mensagemTelefone = document.getElementById('mensagem-fone');
    let mensagemEmail = document.getElementById('mensagem-mail');
    let mensagemProduto = document.getElementById('mensagem-prod');
    let mensagemQuantidade = document.getElementById('mensagem-qtd');
    let mensagemValorUni = document.getElementById('mensagem-val');
    let mensagemStrings = document.getElementById('strings');
    let data = frmRegistro.inData.value;
    let cliente = frmRegistro.inCli.value;
    let telefone = frmRegistro.inFone.value;
    let email = frmRegistro.inMail.value;
    let produto = frmRegistro.inProd.value;
    let quantidade = frmRegistro.inQtd.value;
    let valorUni = frmRegistro.inVal.value;


    if (data.trim() == '') {
        mensagemData.style.display = 'block';
        frmRegistro.inData.focus();
        return false;
    }
    if (cliente.trim() == '') {
        mensagemCliente.style.display = 'block';
        frmRegistro.inCli.focus();
        return false;
    }
    if (cliente.trim() < 5) {
        mensagemStrings.style.display = 'block';
        return false;
    }
    if (telefone.trim() == '') {
        mensagemTelefone.style.display = 'block';
        frmRegistro.inFone.focus();
        return false;
    }
    if (telefone.trim() < 5) {
        mensagemStrings.style.display = 'block';
        return false;
    }
    if (email.trim() == '') {
        mensagemEmail.style.display = 'block';
        frmRegistro.inMail.focus();
        return false;
    }
    if (email.trim() < 5) {
        mensagemStrings.style.display = 'block';
        return false;
    }
    if (produto.trim() == '') {
        mensagemProduto.style.display = 'block';
        frmRegistro.inProd.focus();
        return false;
    }
    if (produto.trim() < 5) {
        mensagemStrings.style.display = 'block';
        return false;
    }
    if (quantidade.trim() == '') {
        mensagemQuantidade.style.display = 'block';
        frmRegistro.inQtd.focus();
        return false;
    }
    if (quantidade.trim() <= 0) {
        mensagemQuantidade.style.display = 'block';
        frmRegistro.inQtd.focus();
        return false;
    }

    if (valorUni.trim() == '') {
        mensagemValorUni.style.display = 'block';
        frmRegistro.inVal.focus();
        return false;
    }

    if (valorUni.trim() <= 0) {
        mensagemValorUni.style.display = 'block';
        frmRegistro.inVal.focus();
        return false;
    }

    alert('Mereço no mínimo nota 100 ;)')
}

/* ----------------------- Atividade 2 -----------------------*/

function atualizarimagens() {
    let dados = document.getElementById('canvas')
        dados.innerHTML = '';
    let qtd = document.getElementById('inQtdImg').value;
    for (let i=0;i<qtd;i++) {
        console.log(i);
        dados.innerHTML += '<img src="img/logo.png" class"imagens" />'
    }

}

/* ----------------------- Atividade 3 -----------------------*/

function acender() {
    let imagem = document.getElementById('lampada');
    let caminho = imagem.src;
    let arquivo = caminho.substring( caminho.lastIndexOf('/')+1 );

    if(arquivo=='acesa.jpg' || arquivo=='')
        imagem.src = 'img/apagada.jpg';
    else
        imagem.src = 'img/acesa.jpg';
    
}

/* ----------------------- Atividade 4 -----------------------*/

document.getElementById("btnEnviar").addEventListener("click", function () {
    var valorPedido = parseFloat(document.getElementById("inValorPedido").value);
    if (valorPedido <= 0) {
        alert("O valor do pedido deve ser maior que zero!");
        return;
    }

    var desconto1 = 0.005;
    var desconto2 = 0.008;
    var desconto3 = 0.01;
    var desconto4 = 0.015;

    var percentualDesconto, valorDesconto;
    if (valorPedido >= 2000) {
        percentualDesconto = desconto4;
    } else if (valorPedido >= 1500) {
        percentualDesconto = desconto3;
    } else if (valorPedido >= 1000) {
        percentualDesconto = desconto2;
    } else if (valorPedido >= 500) {
        percentualDesconto = desconto1;
    } else {
        percentualDesconto = 0;
    }
    valorDesconto = valorPedido * percentualDesconto;

    var valorFinal = valorPedido - valorDesconto;

    document.getElementById("inPercDesc").value = percentualDesconto * 100;
    document.getElementById("inValDesc").value = valorDesconto.toFixed(2);
    document.getElementById("inValFinal").value = valorFinal.toFixed(2);
});